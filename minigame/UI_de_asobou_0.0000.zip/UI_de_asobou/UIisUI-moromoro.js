let talknow = 0;
let x = 0;
let y = 0;  
let z = 0;
let serif1
let serif2
let serif3
let msg1 = [];
let msg2 = [];
let msg3 = [];
let readmessage = 0;
function start(){
    playername = document.getElementById("InputPlayername").value
    if(playername == ''){playername = 'player';document.getElementById('SuguKieru').innerHTML= '';reset();}else{document.getElementById('SuguKieru').innerHTML= '';reset();}
}

function reset(){
  x = 0; y = 0; z = 0;
 chara = ['???','???','ルナ','ルナ','ルナ']
  msg1 = ['お、よく来たね！','私はルナ。','ここでは.....','うーん..','楽しみたかったら楽しんでね〜！'];
  msg2 = ['(zキーで進みます)','','','やっぱめんどいから説明は無しで！','あ、ゆっくりしていってね！'];
  msg3 = ['','','','',''];
  talknow = 1; readmessage = 0;
  Nextmsg();
}
function c(name){document.getElementById('CharacterName').innerHTML = name;}
function s1(msg){document.getElementById('serif1').innerHTML = msg;}
function s2(msg){document.getElementById('serif2').innerHTML = msg;}
function s3(msg){document.getElementById('serif3').innerHTML = msg;}
function Nextmsg(){
    c(chara[readmessage]);
    s1(msg1[readmessage]);
    s2(msg2[readmessage]);
    s3(msg3[readmessage]);
}
document.addEventListener('keydown', (event) => {
    if(talknow == 1){
    if (event.key === 'z') {
        readmessage++;
        if (readmessage < msg1.length) {
            Nextmsg();
        } else {
            c('ルナ');
            s1('これが最後のメッセージです。'); // 全てのメッセージを表示し終えた場合の処理
            s2('ctrl+rを押したらいいんじゃないかな!');
            s3('');
        }
    }
}});